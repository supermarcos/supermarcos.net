# AUTOGURU TEST

This is my test for AutoGuru, and API application built in .NET and a FrontEnd application built in Angular

## Getting Started

There are two main directories:
* API
* AutoGuruApp

#### API
Contains the .net project with the API
#### AutoGuruApp
Contains the Angular application

### Prerequisites

* .Net Core installed on the server
* node
* npm
* angular-cli


### Installing

Running the API backend (it will listen on the port 5000 by default):

In a terminal, go to `API` folder and run:
```
dotnet run
```
Running the angular server (it expects the API to be working on the port 5000):

In a terminal, go to `AutoGuruApp` folder and run:
```
ng serve
```

## Running the tests

*TODO:* explain how to run the unit tests for both .net and angular... if I have time to finish them...
