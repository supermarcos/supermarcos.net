import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Member } from '../models/Member.model';

// by default some browsers don't use application/json
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class MemberService {
    public member: Member;
    private baseUrl: string = 'http://localhost:5000/api';  // TODO: move this to the general configuration

    constructor(private http: HttpClient) {

    }

    /**
     * Getting a list of all members
     */
    getAllMembers(): Observable<Member[]> {
        const members: Member[] = this.http.get(`${this.baseUrl}/member`, httpOptions)
                        .map(this.mapMembers);
        return members;
    }

    /**
     * Getting a particular member
     * @param id the members id
     */
    getMemberById(id: string): Observable<Member> {
        console.log('getting the user by the id...');
        const member: Member = this.http.get<Member>(`/api/member/${id}`, httpOptions)
                        .map(this.mapMember);
        return member;
    }

    createMember(member: Member): Observable<Member> {
        const payLoad = JSON.stringify(member);
        return this.http.post(`${this.baseUrl}/member`, payLoad, httpOptions);
    }

    updateMember(member: Member): Observable<Member> {
        const payLoad = JSON.stringify(member);
        return this.http.put(`${this.baseUrl}/member/` + member.id, payLoad, httpOptions);
    }

    // TODO: in this the observable probably doesn't need to be a Member type
    deleteMember(member: Member): Observable<Member> {
        return this.http.delete(`${this.baseUrl}/member/` + member.id);
    }

    /* mapping responses */
    private mapMembers(response: Response): Member[] {
        return response.json().results.map(this.toMember);
    }

    private mapMember(response: Response): Member {
        return this.toMember(response.json());
    }

    private toMember(res: any): Member {
        const member = <Member>({
            id: res.id,
            name: res.name,
        });
        return member;
    }
}
