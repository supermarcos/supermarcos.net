import { Component } from '@angular/core';
import { NgClass } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { MemberService } from './services/member.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'AutoGuru Angular App';

  openOffCanvas = false;

  members: Member[] = [];

  constructor(private _memberService: MemberService) { }

  toggleOffCanvas() {
    this.openOffCanvas = !this.openOffCanvas;
  }
}
