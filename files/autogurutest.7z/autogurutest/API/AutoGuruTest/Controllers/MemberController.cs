﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoGuruTest.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    public class MemberController : Controller
    {
        // GET: api/Member to list members
        // TODO: bare lists are costly, we should paginate the results
        [HttpGet]
        public IActionResult GetAll()
        {
            // TODO: use the mocked member.json file to return data instead of hardcoding it here...
            return Ok(new string[] { "member1", "member2" });
        }

        // GET: api/Member/5
        [HttpGet("{id}", Name = "Get")]
        public IActionResult GetById(int id)
        {
            return Ok("member 5...");
        }
        
        // POST: api/Member to create a new member
        [HttpPost]
        public IActionResult Post([FromBody]string value)
        {
            // TODO: how to return the url of the created resource? maybe just the new id...?
            return Created("123", value);
        }
        
        // PUT: api/Member/5 to patch or update an existing member
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]string value)
        {
            return Ok("updated...");
        }

        // DELETE: api/ApiWithActions/5 to delete an existing member
        // NOTE: in a real world we probably don't want to release in production a truly deletion system, 
        //       but a "delete" system that actually deactivates the member, it all depends of the data architecture approach behind
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok("deleted...");
        }
    }
}
