﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace AutoGuruTest.Models
{
    // although the DataAnnotations on the fields are more useful for MVC webforms, it doesn't harm having them here and helps to understand the model better
    public class Member
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(255)]
        public string Email { get; set; }
        public DateTimeOffset CreatedDate { get; set; }
        [Required]
        [MaxLength(255)]
        public string FirstName { get; set; }
        [Required]
        [MaxLength(255)]
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string WebSite { get; set; }
        public bool IsAdministrator { get; set; }
    }
}
